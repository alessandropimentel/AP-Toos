# -*- coding: utf-8 -*-
"""
AP Toos QGIS Plugin
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

def classFactory(iface):
    from .ap_toos_plugin import APToosPlugin
    return APToosPlugin(iface)
