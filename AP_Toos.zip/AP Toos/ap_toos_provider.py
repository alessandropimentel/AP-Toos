# -*- coding: utf-8 -*-
"""
AP Toos QGIS Processing Provider
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

import os
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon

from .algorithms.coordinate_generator import CoordinateGenerator
from .algorithms.kmz_generator import KMZGenerator
from .algorithms.create_point import CreatePoint
from .algorithms.area_calculator import AreaCalculator
from .algorithms.merge_layers import MergeLayers
from .algorithms.reproject_layer import ReprojectLayer
from .algorithms.photo_reader import PhotoReader
from .algorithms.create_layer import CreateLayer

class APToosProvider(QgsProcessingProvider):
    """Provedor de processamento que agrupa todas as ferramentas do AP Toos."""

    def __init__(self):
        super(APToosProvider, self).__init__()

    def unload(self):
        """Ações ao descarregar o provedor."""
        pass

    def loadAlgorithms(self):
        """Adiciona os algoritmos ao provedor."""
        self.addAlgorithm(CoordinateGenerator())
        self.addAlgorithm(KMZGenerator())
        self.addAlgorithm(CreatePoint())
        self.addAlgorithm(AreaCalculator())
        self.addAlgorithm(MergeLayers())
        self.addAlgorithm(ReprojectLayer())
        self.addAlgorithm(PhotoReader())
        self.addAlgorithm(CreateLayer())

    def id(self):
        """Identificador único do provedor."""
        return 'ap_toos'

    def name(self):
        """Nome visível na Caixa de Ferramentas de Processamento."""
        return QCoreApplication.translate('APToosProvider', 'AP Toos')

    def icon(self):
        """Retorna o ícone do provedor."""
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return QgsProcessingProvider.icon(self)

    def longName(self):
        """Nome descritivo longo do provedor."""
        return QCoreApplication.translate('APToosProvider', 'AP Toos - Ferramentas de Geoprocessamento')
