# -*- coding: utf-8 -*-
"""
AP Toos QGIS Plugin Class
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

from qgis.core import QgsApplication
from .ap_toos_provider import APToosProvider

class APToosPlugin(object):
    """Classe principal do plugin AP Toos que gerencia seu ciclo de vida no QGIS."""

    def __init__(self, iface):
        """Construtor.
        
        :param iface: Instância da interface do QGIS (QgisInterface)
        """
        self.iface = iface
        self.provider = None

    def initGui(self):
        """Inicializa a interface gráfica do plugin e registra o provedor de processamento."""
        self.provider = APToosProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        """Remove o plugin da interface do QGIS e desregistra o provedor de processamento."""
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
