# AP Toos

Plugin de Geoprocessamento para o QGIS com ferramentas utilitárias avançadas.

Desenvolvido por **Alessandro Pimentel**, Especialista em Geoprocessamento.

---

## 🛠️ Ferramentas Incluídas

O **AP Toos** adiciona um painel com as seguintes ferramentas de processamento no QGIS:

1.  **Leitor de Fotos**
    *   Lê coordenadas geográficas embutidas no EXIF de fotos georreferenciadas.
    *   **OCR Integrado**: Se a foto não possuir tags GPS, realiza leitura OCR na imagem (prints, fotos de telas) para extrair datas e coordenadas geográficas (suporta 10 formatos diferentes: Graus Decimais, GMS, GMD, UTM, MGRS, ECEF, UPS, etc.).
    *   **Geocodificação fallback**: Se nenhuma coordenada direta for encontrada no texto, extrai e geocodifica o endereço via OpenStreetMap Nominatim.
    *   **Escrita Física**: Grava as coordenadas encontradas de volta nos metadados EXIF da imagem.
    *   **Pop-up Responsivo**: Configura visualizador responsivo para fotos anexas nos atributos.
2.  **Criar Camada**
    *   Cria novas camadas (Pontos, Linhas ou Polígonos), tanto temporárias em memória quanto como Shapefile (.shp).
    *   **Autopreenchimento Dinâmico**:
        *   `ID` sequencial automático (`coalesce(maximum("ID"), 0) + 1`).
        *   `DT_CRIACAO` automatizada.
        *   `AREA_HA` (para polígonos) calculada e atualizada dinamicamente em tempo real sempre que a geometria for modificada.
        *   `PERIM_M` (para linhas) calculado e atualizado dinamicamente.
        *   Coordenadas `LONG_GD`, `LAT_GD`, `LONG_GMS`, `LAT_GMS`, `LONG_UTM`, `LAT_UTM` (para pontos) calculadas e atualizadas dinamicamente.
3.  **Gerador de KMZ**
    *   Exporta qualquer camada vetorial para arquivo compactado `.kmz` para abertura no Google Earth.
    *   **Preservação de Estilos**: Mantém a simbologia (cores, larguras de linhas) e rótulos aplicados no QGIS.
4.  **Gerador de Coordenadas SIRGAS**
5.  **Calculadora de Área**
6.  **Juntar Camadas**
7.  **Reprojetar Camada**

---

## ⚙️ Dependências e Requisitos

O plugin foi projetado para rodar de forma leve e offline:
*   **OCR Nativo no Windows**: O plugin tenta usar o motor de OCR nativo do Windows 10/11 (`Windows.Media.Ocr`) via PowerShell para rodar de forma offline e sem nenhuma instalação adicional.
*   **Fallback Pytesseract**: Caso o OCR nativo do Windows não esteja disponível, o plugin pode utilizar a biblioteca `pytesseract` (requer instalação do Tesseract OCR no sistema).
*   **Bibliotecas Python**: O plugin gerencia e instala automaticamente via pip em segundo plano as dependências necessárias (`piexif` e `pytesseract`) na primeira inicialização.

---

## ⚖️ Licença

Este plugin é software livre e está licenciado sob a **GNU General Public License v2 (GPLv2) ou posterior**. Veja o arquivo `LICENSE` para mais detalhes.
