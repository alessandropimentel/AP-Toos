# -*- coding: utf-8 -*-
"""
AP Toos - Gerador de Coordenadas
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingException,
    QgsField,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsProject,
    QgsFeatureSink
)
from qgis.PyQt.QtCore import QVariant, QCoreApplication


def get_sirgas2000_utm_epsg(lon, lat):
    """Determina o código EPSG UTM adequado para SIRGAS 2000 com base na coordenada.
    Caso esteja fora da cobertura do SIRGAS 2000, faz o fallback para WGS 84 UTM.
    """
    zone = int((lon + 180) / 6) + 1
    is_south = lat < 0

    if is_south:
        # Zonas do Hemisfério Sul para SIRGAS 2000 (Zonas 17S a 25S)
        if 17 <= zone <= 25:
            return 31977 + (zone - 17)
    else:
        # Zonas do Hemisfério Norte para SIRGAS 2000 (Zonas 18N a 22N, 23N, 24N)
        if 18 <= zone <= 22:
            return 31972 + (zone - 18)
        elif zone == 23:
            return 6210
        elif zone == 24:
            return 6211

    # Fallback robusto para WGS 84 UTM
    if is_south:
        return 32700 + zone
    else:
        return 32600 + zone


def format_dms(val, is_lat):
    """Formata um valor decimal em Graus, Minutos e Segundos (GMS) com separador de vírgula.
    
    Ex: 47°48'6,88"W
    """
    if is_lat:
        cardinal = 'N' if val >= 0 else 'S'
    else:
        cardinal = 'E' if val >= 0 else 'W'

    abs_val = abs(val)
    degrees = int(abs_val)
    minutes = int((abs_val - degrees) * 60)
    seconds = (abs_val - degrees - minutes / 60.0) * 3600.0

    # Ajuste de arredondamento para evitar 60.00 segundos
    if seconds >= 59.995:
        seconds = 0.0
        minutes += 1
        if minutes >= 60:
            minutes = 0
            degrees += 1

    sec_str = f"{seconds:.2f}".replace('.', ',')
    return f"{degrees}°{minutes}'{sec_str}\"{cardinal}"


class CoordinateGenerator(QgsProcessingAlgorithm):
    """Gerador de Coordenadas - Adiciona coordenadas GD, UTM e GMS na tabela de atributos."""

    INPUT = 'INPUT'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                QCoreApplication.translate('CoordinateGenerator', 'Camada de Ponto de Entrada (SIRGAS 2000 - EPSG:4674)'),
                [QgsProcessing.TypeVectorPoint]
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                QCoreApplication.translate('CoordinateGenerator', 'Camada de Saída')
            )
        )

    def name(self):
        return 'coordinate_generator'

    def displayName(self):
        return QCoreApplication.translate('CoordinateGenerator', 'Gerador de Coordenadas')

    def group(self):
        return QCoreApplication.translate('CoordinateGenerator', 'Vetores')

    def groupId(self):
        return 'vetores'

    def shortHelpString(self):
        return QCoreApplication.translate(
            'CoordinateGenerator',
            "Gera campos na tabela de atributos contendo as coordenadas em Graus Decimais (GD), "
            "UTM e Graus, Minutos e Segundos (GMS).\n\n"
            "A camada de ponto de entrada deve estar obrigatoriamente no sistema de coordenadas SIRGAS 2000 (EPSG:4674).\n\n"
            "Copyright: © Alessandro Pimentel 2026, Especialista em Geoprocessamento"
        )

    def createInstance(self):
        return CoordinateGenerator()

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.tr("Não foi possível carregar a camada de entrada."))

        # Validação obrigatória do CRS: deve ser SIRGAS 2000 (EPSG:4674)
        crs = source.sourceCrs()
        if crs.authid() != 'EPSG:4674':
            raise QgsProcessingException(
                self.tr(f"A camada de ponto de entrada deve estar em SIRGAS 2000 (EPSG:4674). "
                        f"A camada atual está em: {crs.authid()}")
            )

        # Preparar novos campos
        fields = source.fields()
        fields.append(QgsField('LONG_GD', QVariant.Double, 'Double', 20, 8))
        fields.append(QgsField('LAT_GD', QVariant.Double, 'Double', 20, 8))
        fields.append(QgsField('LONG_UTM', QVariant.Int, 'Integer'))
        fields.append(QgsField('LAT_UTM', QVariant.Int, 'Integer'))
        fields.append(QgsField('LONG_GMS', QVariant.String, 'String', 50))
        fields.append(QgsField('LAT_GMS', QVariant.String, 'String', 50))

        # Configurar pia de saída (sink)
        (sink, dest_id) = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            fields,
            source.wkbType(),
            source.sourceCrs()
        )

        if sink is None:
            raise QgsProcessingException(self.tr("Não foi possível criar o arquivo de saída."))

        # Processar feições
        features = source.getFeatures()
        total = 100.0 / source.featureCount() if source.featureCount() > 0 else 0

        # Dicionário de cache de transformações para otimizar performance
        transform_cache = {}

        for current, feature in enumerate(features):
            if feedback.isCanceled():
                break

            geom = feature.geometry()
            new_feature = QgsFeature(feature)
            
            # Inicializa os novos atributos como NULL caso a geometria seja inválida
            long_gd = QVariant(QVariant.Double)
            lat_gd = QVariant(QVariant.Double)
            long_utm = QVariant(QVariant.Int)
            lat_utm = QVariant(QVariant.Int)
            long_gms = QVariant(QVariant.String)
            lat_gms = QVariant(QVariant.String)

            if geom is not None and not geom.isEmpty() and geom.isMultipart() is False:
                pt = geom.asPoint()
                lon = pt.x()
                lat = pt.y()

                # 1. Graus Decimais (GD) arredondados para 4 casas decimais conforme a imagem coord1
                long_gd = round(lon, 4)
                lat_gd = round(lat, 4)

                # 2. Graus, Minutos e Segundos (GMS) calculados com precisão total
                long_gms = format_dms(lon, is_lat=False)
                lat_gms = format_dms(lat, is_lat=True)

                # 3. UTM (Projeção dinâmica com base no fuso e hemisfério)
                utm_epsg = get_sirgas2000_utm_epsg(lon, lat)
                
                if utm_epsg not in transform_cache:
                    utm_crs = QgsCoordinateReferenceSystem(f"EPSG:{utm_epsg}")
                    transform_cache[utm_epsg] = QgsCoordinateTransform(
                        crs, 
                        utm_crs, 
                        context.transformContext() if hasattr(context, 'transformContext') else QgsProject.instance()
                    )
                
                try:
                    utm_pt = transform_cache[utm_epsg].transform(pt)
                    long_utm = int(round(utm_pt.x()))
                    lat_utm = int(round(utm_pt.y()))
                except Exception as e:
                    feedback.reportError(f"Erro ao projetar ponto {pt.toString()} para UTM (EPSG:{utm_epsg}): {str(e)}")

            # Definir novos atributos
            new_attrs = feature.attributes() + [long_gd, lat_gd, long_utm, lat_utm, long_gms, lat_gms]
            new_feature.setAttributes(new_attrs)
            sink.addFeature(new_feature, QgsFeatureSink.FastInsert)

            feedback.setProgress(int(current * total))

        feedback.pushInfo("© Alessandro Pimentel 2026, Especialista em Geoprocessamento - Processamento Concluído com Sucesso!")
        return {self.OUTPUT: dest_id}
