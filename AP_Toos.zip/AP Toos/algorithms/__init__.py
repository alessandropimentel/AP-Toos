# -*- coding: utf-8 -*-
"""
AP Toos Algorithms Package
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""
