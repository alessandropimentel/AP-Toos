# -*- coding: utf-8 -*-
"""
AP Toos - Gerador de KMZ
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

import os
import tempfile
import zipfile
import processing

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
    QgsVectorFileWriter,
    QgsProject,
    QgsProcessingUtils
)
from qgis.PyQt.QtCore import QCoreApplication


class KMZGenerator(QgsProcessingAlgorithm):
    """Gerador de KMZ - Exporta qualquer camada vetorial para arquivo KMZ."""

    INPUT = 'INPUT'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                QCoreApplication.translate('KMZGenerator', 'Camada Vetorial de Entrada'),
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT,
                QCoreApplication.translate('KMZGenerator', 'Arquivo KMZ de Saída'),
                fileFilter='KMZ files (*.kmz)'
            )
        )

    def name(self):
        return 'kmz_generator'

    def displayName(self):
        return QCoreApplication.translate('KMZGenerator', 'Gerador de KMZ')

    def group(self):
        return QCoreApplication.translate('KMZGenerator', 'Vetores')

    def groupId(self):
        return 'vetores'

    def shortHelpString(self):
        return QCoreApplication.translate(
            'KMZGenerator',
            "Gera um arquivo KMZ compactado a partir de qualquer camada vetorial de entrada.\n\n"
            "O algoritmo realiza automaticamente a reprojeção dos dados para WGS 84 (EPSG:4326), "
            "conforme exigido pelo padrão KML/KMZ.\n\n"
            "Copyright: © Alessandro Pimentel 2026, Especialista em Geoprocessamento"
        )

    def createInstance(self):
        return KMZGenerator()

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.tr("Não foi possível carregar a camada de entrada."))

        output_file = self.parameterAsFileOutput(parameters, self.OUTPUT, context)
        if not output_file:
            raise QgsProcessingException(self.tr("Caminho do arquivo de saída não especificado."))

        # Garantir extensão .kmz
        if not output_file.lower().endswith('.kmz'):
            output_file += '.kmz'

        feedback.pushInfo(f"Reprojetando camada para WGS 84 (EPSG:4326)...")

        # 1. Reprojetar para EPSG:4326 usando o algoritmo nativo
        reproject_params = {
            'INPUT': parameters[self.INPUT],
            'TARGET_CRS': 'EPSG:4326',
            'OUTPUT': 'memory:reprojected_kml'
        }
        
        reprojected_result = processing.run(
            "native:reprojectlayer",
            reproject_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )
        
        temp_layer_id = reprojected_result['OUTPUT']
        if temp_layer_id is None:
            raise QgsProcessingException(self.tr("Erro ao reprojetar a camada."))

        temp_layer = QgsProcessingUtils.mapLayerFromString(temp_layer_id, context)
        if temp_layer is None:
            raise QgsProcessingException(self.tr("Não foi possível mapear o identificador para a camada de vetor."))

        # Copiar a simbologia/estilo da camada de entrada original para a camada temporária reprojetada
        input_layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        if input_layer and temp_layer:
            if input_layer.renderer():
                temp_layer.setRenderer(input_layer.renderer().clone())
            if hasattr(input_layer, 'labelsEnabled') and input_layer.labelsEnabled():
                temp_layer.setLabeling(input_layer.labeling().clone())
                temp_layer.setLabelsEnabled(True)
            temp_layer.triggerRepaint()

        feedback.pushInfo("Escrevendo arquivo KML temporário...")

        # 2. Escrever a camada reprojetada para um arquivo KML temporário
        temp_dir = tempfile.gettempdir()
        temp_kml_path = os.path.join(temp_dir, "doc.kml")

        # Remover arquivo temporário pré-existente
        if os.path.exists(temp_kml_path):
            try:
                os.remove(temp_kml_path)
            except Exception as e:
                feedback.reportError(f"Aviso ao remover KML temporário antigo: {str(e)}")

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "KML"
        options.fileEncoding = "UTF-8"
        options.symbologyExport = QgsVectorFileWriter.FeatureSymbology

        transform_context = context.transformContext() if hasattr(context, 'transformContext') else QgsProject.instance().transformContext()

        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            temp_layer,
            temp_kml_path,
            transform_context,
            options
        )
        err = result[0]
        err_msg = result[1] if len(result) > 1 else ""

        if err != QgsVectorFileWriter.NoError:
            raise QgsProcessingException(self.tr(f"Erro ao salvar KML temporário: {err_msg}"))

        feedback.pushInfo("Compactando KML em arquivo KMZ...")

        # 3. Compactar o KML temporário em um arquivo KMZ
        try:
            # Garante que a pasta de destino exista
            dest_dir = os.path.dirname(output_file)
            if dest_dir and not os.path.exists(dest_dir):
                os.makedirs(dest_dir, exist_ok=True)

            with zipfile.ZipFile(output_file, 'w', zipfile.ZIP_DEFLATED) as kmz:
                kmz.write(temp_kml_path, "doc.kml")
        except Exception as e:
            raise QgsProcessingException(self.tr(f"Erro ao criar arquivo KMZ final: {str(e)}"))
        finally:
            # Limpar KML temporário
            if os.path.exists(temp_kml_path):
                try:
                    os.remove(temp_kml_path)
                except Exception as e:
                    feedback.reportError(f"Aviso ao remover KML temporário após compactação: {str(e)}")

        feedback.pushInfo(f"Arquivo KMZ criado com sucesso em: {output_file}")
        feedback.pushInfo("© Alessandro Pimentel 2026, Especialista em Geoprocessamento - KMZ Gerado!")

        return {self.OUTPUT: output_file}
