# -*- coding: utf-8 -*-
"""
AP Toos - Juntar Camada Vetorial
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

import processing
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterFeatureSink,
    QgsProcessingException
)
from qgis.PyQt.QtCore import QCoreApplication


class MergeLayers(QgsProcessingAlgorithm):
    """Juntar Camada Vetorial - Mescla várias camadas vetoriais em uma única camada."""

    LAYERS = 'LAYERS'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.LAYERS,
                QCoreApplication.translate('MergeLayers', 'Camadas Vetoriais para Juntar'),
                layerType=QgsProcessing.TypeVector
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                QCoreApplication.translate('MergeLayers', 'Camada Mesclada Final')
            )
        )

    def name(self):
        return 'merge_layers'

    def displayName(self):
        return QCoreApplication.translate('MergeLayers', 'Juntar Camada Vetorial')

    def group(self):
        return QCoreApplication.translate('MergeLayers', 'Vetores')

    def groupId(self):
        return 'vetores'

    def shortHelpString(self):
        return QCoreApplication.translate(
            'MergeLayers',
            "Mescla múltiplas camadas vetoriais de entrada em uma única camada final.\n\n"
            "Esta ferramenta aceita camadas com as mesmas geometrias ou geometrias compatíveis. "
            "Os atributos de todas as tabelas originais serão mesclados e preservados no resultado final.\n\n"
            "Copyright: © Alessandro Pimentel 2026, Especialista em Geoprocessamento"
        )

    def createInstance(self):
        return MergeLayers()

    def processAlgorithm(self, parameters, context, feedback):
        layers = self.parameterAsLayerList(parameters, self.LAYERS, context)
        if not layers:
            raise QgsProcessingException(self.tr("Nenhuma camada foi selecionada para mesclagem."))

        feedback.pushInfo(f"Mesclando {len(layers)} camadas vetoriais...")

        # Configurar parâmetros para o algoritmo nativo do QGIS
        merge_params = {
            'LAYERS': parameters[self.LAYERS],
            'CRS': None,  # Utiliza o CRS da primeira camada
            'OUTPUT': parameters[self.OUTPUT]
        }

        # Rodar o algoritmo filho
        results = processing.run(
            "native:mergevectorlayers",
            merge_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        dest_id = results.get('OUTPUT')
        if dest_id is None:
            raise QgsProcessingException(self.tr("Erro ao executar a mesclagem de camadas."))

        feedback.pushInfo("© Alessandro Pimentel 2026, Especialista em Geoprocessamento - Camadas Mescladas!")
        return {self.OUTPUT: dest_id}
