# -*- coding: utf-8 -*-
"""
AP Toos - Leitor de Fotos
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

import os
import re
import sys
import subprocess
import json
import math
import urllib.request
import urllib.parse
from fractions import Fraction

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFeatureSink,
    QgsProcessingException,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsWkbTypes,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsEditorWidgetSetup,
    QgsProcessingUtils
)
from qgis.PyQt.QtCore import QVariant, QCoreApplication


def ensure_dependencies(feedback):
    """Instala bibliotecas necessárias dinamicamente no Python do QGIS."""
    python_exe = sys.executable
    exec_dir = os.path.dirname(sys.executable)
    
    for name in ['python3.exe', 'python.exe', 'pythonw.exe']:
        path = os.path.join(exec_dir, name)
        if os.path.exists(path):
            python_exe = path
            break
    else:
        for name in ['python.exe', 'pythonw.exe', 'bin/python.exe', 'bin/pythonw.exe']:
            path = os.path.join(sys.exec_prefix, name)
            if os.path.exists(path):
                python_exe = path
                break

    startupinfo = None
    if sys.platform == 'win32':
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0  # SW_HIDE

    # Instalar piexif
    try:
        import piexif
    except ImportError:
        feedback.pushInfo("Biblioteca 'piexif' não encontrada. Instalando via pip...")
        try:
            subprocess.check_call([python_exe, "-m", "pip", "install", "piexif"], startupinfo=startupinfo)
            feedback.pushInfo("Biblioteca 'piexif' instalada com sucesso!")
        except Exception as e:
            feedback.reportError(f"Falha ao instalar 'piexif': {str(e)}. A escrita de metadados EXIF estará desabilitada.")

    # Instalar pytesseract
    try:
        import pytesseract
    except ImportError:
        feedback.pushInfo("Biblioteca 'pytesseract' não encontrada. Instalando via pip...")
        try:
            subprocess.check_call([python_exe, "-m", "pip", "install", "pytesseract"], startupinfo=startupinfo)
            feedback.pushInfo("Biblioteca 'pytesseract' instalada com sucesso!")
        except Exception as e:
            feedback.pushInfo(f"Não foi possível instalar 'pytesseract' via pip: {str(e)}.")


class PhotoReader(QgsProcessingAlgorithm):
    """Leitor de Fotos - Extrai coordenadas de fotos georreferenciadas ou via OCR de imagem."""

    PHOTO_PATH = 'PHOTO_PATH'
    FOLDER_PATH = 'FOLDER_PATH'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.PHOTO_PATH,
                QCoreApplication.translate('PhotoReader', 'Arquivo de Imagem (Foto) (Opcional)'),
                behavior=QgsProcessingParameterFile.File,
                fileFilter='Image files (*.jpg *.jpeg *.png *.tif *.tiff)',
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterFile(
                self.FOLDER_PATH,
                QCoreApplication.translate('PhotoReader', 'Pasta com Imagens (Opcional)'),
                behavior=QgsProcessingParameterFile.Folder,
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                QCoreApplication.translate('PhotoReader', 'Pontos das Fotos')
            )
        )

    def name(self):
        return 'photo_reader'

    def displayName(self):
        return QCoreApplication.translate('PhotoReader', 'Leitor de Fotos')

    def group(self):
        return QCoreApplication.translate('PhotoReader', 'Imagens')

    def groupId(self):
        return 'imagens'

    def shortHelpString(self):
        return QCoreApplication.translate(
            'PhotoReader',
            "Extrai coordenadas geográficas de fotos.\n\n"
            "Esta ferramenta aceita uma imagem individual ou uma pasta inteira contendo fotos. "
            "Se a foto contiver tags GPS EXIF, plota o ponto diretamente. "
            "Caso contrário, executa análise de OCR na imagem para extrair qualquer "
            "texto contendo coordenadas (Graus Decimais, GMS ou UTM). "
            "Se coordenadas forem identificadas via OCR, elas são gravadas de volta no EXIF da foto.\n\n"
            "Copyright: © Alessandro Pimentel 2026, Especialista em Geoprocessamento"
        )

    def createInstance(self):
        return PhotoReader()

    def processAlgorithm(self, parameters, context, feedback):
        ensure_dependencies(feedback)

        photo_path = self.parameterAsFile(parameters, self.PHOTO_PATH, context)
        folder_path = self.parameterAsFile(parameters, self.FOLDER_PATH, context)

        if not photo_path and not folder_path:
            raise QgsProcessingException(self.tr("Você deve especificar um Arquivo de Imagem OU uma Pasta com Imagens."))

        # Listar arquivos para processar
        files_to_process = []
        if photo_path and os.path.exists(photo_path):
            files_to_process.append(photo_path)

        if folder_path and os.path.exists(folder_path):
            extensions = ('.jpg', '.jpeg', '.png', '.tif', '.tiff')
            for filename in os.listdir(folder_path):
                if filename.lower().endswith(extensions):
                    files_to_process.append(os.path.join(folder_path, filename))

        if not files_to_process:
            raise QgsProcessingException(self.tr("Nenhum arquivo de imagem válido foi encontrado nos parâmetros fornecidos."))

        # Configurar atributos de saída
        fields = QgsFields()
        fields.append(QgsField('photo_path', QVariant.String, 'String', 255))
        fields.append(QgsField('source', QVariant.String, 'String', 50))
        fields.append(QgsField('latitude', QVariant.Double, 'Double', 20, 8))
        fields.append(QgsField('longitude', QVariant.Double, 'Double', 20, 8))
        fields.append(QgsField('datetime', QVariant.String, 'String', 50))
        fields.append(QgsField('ocr_text', QVariant.String, 'String', 2000))

        # Configurar pia de saída (saída sempre em WGS 84 - EPSG:4326 para fotos)
        out_crs = QgsCoordinateReferenceSystem("EPSG:4326")
        (sink, dest_id) = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            fields,
            QgsWkbTypes.Point,
            out_crs
        )

        if sink is None:
            raise QgsProcessingException(self.tr("Não foi possível criar a camada de saída."))

        total = len(files_to_process)
        feedback.pushInfo(f"Iniciando processamento de {total} foto(s)...")

        for idx, current_photo in enumerate(files_to_process):
            if feedback.isCanceled():
                break

            feedback.pushInfo(f"[{idx + 1}/{total}] Processando arquivo: {current_photo}")
            
            # Tentar ler metadados (EXIF, ou fazer fallback para OCR/Geocoding)
            meta = self.get_exif_metadata_advanced(current_photo, feedback)
            
            lat = meta['latitude']
            lon = meta['longitude']
            datetime_str = meta['date_time']
            source_type = meta['coord_format'] or "N/A"
            ocr_text_extracted = meta.get('ocr_text_raw', "")

            # Exibe Relatório no log
            feedback.pushInfo("=" * 70)
            feedback.pushInfo("        SISTEMA AVANÇADO DE OCR E ANÁLISE DOCUMENTAL - AP TOOS")
            feedback.pushInfo("=" * 70)
            feedback.pushInfo(f"Arquivo analisado: {current_photo}")
            feedback.pushInfo("-" * 70)
            feedback.pushInfo("CONTEÚDO TEXTUAL EXTRAÍDO INTEGRALMENTE:")
            if ocr_text_extracted:
                for line in ocr_text_extracted.split('\n'):
                    if line.strip():
                        feedback.pushInfo(f"  {line}")
            else:
                feedback.pushInfo("  [Nenhum texto de OCR extraído ou EXIF nativo utilizado]")
            feedback.pushInfo("-" * 70)

            if lat is not None and lon is not None:
                feedback.pushInfo(f"  Coordenadas identificadas via {source_type}: Lat {lat}, Lon {lon}")
                if meta.get('exif_written'):
                    feedback.pushInfo(f"  Metadados EXIF atualizados fisicamente no arquivo: {current_photo}")
            else:
                feedback.reportError(f"  Não foi possível extrair coordenadas geográficas para o arquivo: {current_photo}")
            feedback.pushInfo("=" * 70)

            # 3. Adicionar feição se as coordenadas foram resolvidas
            if lat is not None and lon is not None:
                feature = QgsFeature()
                feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
                feature.setAttributes([
                    current_photo,
                    source_type,
                    lat,
                    lon,
                    datetime_str,
                    ocr_text_extracted[:2000]
                ])
                sink.addFeature(feature)
            else:
                feedback.reportError(f"  Ignorado arquivo sem coordenadas geográficas: {current_photo}")

            feedback.setProgress(int((idx + 1) * 100.0 / total))

        self.dest_id = dest_id
        feedback.pushInfo("© Alessandro Pimentel 2026, Especialista em Geoprocessamento - Leitura Concluída!")
        return {self.OUTPUT: dest_id}

    def postProcessAlgorithm(self, context, feedback):
        if hasattr(self, 'dest_id') and self.dest_id:
            layer = QgsProcessingUtils.mapLayerFromString(self.dest_id, context)
            if layer:
                field_index = layer.fields().indexFromName('photo_path')
                if field_index != -1:
                    widget_setup = QgsEditorWidgetSetup(
                        'ExternalResource',
                        {
                            'FileWidget': True,
                            'DocumentViewer': 1,        # 1 = Image viewer
                            'RelativeStorage': 0,       # 0 = Absolute paths
                            'StorageMode': 0,           # 0 = Select file
                            'DocumentViewerHeight': 0, # 0 = automatic resizing
                            'DocumentViewerWidth': 0,
                            'FileWidgetButton': True,
                            'FileWidgetFilter': ''
                        }
                    )
                    layer.setEditorWidgetSetup(field_index, widget_setup)
                    feedback.pushInfo("Configurado visualizador de imagens no campo 'photo_path' para exibições em pop-ups.")
        return super(PhotoReader, self).postProcessAlgorithm(context, feedback)

    # ===================================================================
    # MÉTODOS DE OCR E CONVERSÃO DO SCRIPT NATIVO (leitura_imagem_campo)
    # ===================================================================

    def convert_to_degrees(self, value):
        try:
            d = float(value[0])
            m = float(value[1])
            s = float(value[2])
            return d + (m / 60.0) + (s / 3600.0)
        except Exception:
            return 0.0

    def utm_to_wgs84(self, zone, band, easting, northing):
        try:
            is_southern = band.upper() <= 'M'
            epsg = 32700 + int(zone) if is_southern else 32600 + int(zone)
            src_crs = QgsCoordinateReferenceSystem(f"EPSG:{epsg}")
            dest_crs = QgsCoordinateReferenceSystem("EPSG:4326")
            project = QgsProject.instance()
            transform = QgsCoordinateTransform(src_crs, dest_crs, project)
            point = QgsPointXY(float(easting), float(northing))
            transformed = transform.transform(point)
            return transformed.y(), transformed.x()
        except Exception:
            return None, None

    def ecef_to_wgs84(self, x, y, z):
        a = 6378137.0
        e2 = 6.6943799901377997e-3
        p = math.sqrt(x*x + y*y)
        th = math.atan2(a * z, p * math.sqrt(1 - e2) * a)
        lon = math.atan2(y, x)
        lat = math.atan2(z + e2 / (1 - e2) * a * math.sin(th)**3,
                         p - e2 * a * math.cos(th)**3)
        lat_deg = math.degrees(lat)
        lon_deg = math.degrees(lon)
        if -90 <= lat_deg <= 90 and -180 <= lon_deg <= 180:
            return lat_deg, lon_deg
        return None, None

    def _project_polar(self, dist_m, azimuth_deg, origin_lat, origin_lon):
        R = 6371000.0
        az = math.radians(azimuth_deg)
        lat1 = math.radians(origin_lat)
        lon1 = math.radians(origin_lon)
        d = dist_m / R
        lat2 = math.asin(math.sin(lat1) * math.cos(d) +
                         math.cos(lat1) * math.sin(d) * math.cos(az))
        lon2 = lon1 + math.atan2(math.sin(az) * math.sin(d) * math.cos(lat1),
                                 math.cos(d) - math.sin(lat1) * math.sin(lat2))
        return math.degrees(lat2), math.degrees(lon2)

    def mgrs_to_wgs84(self, mgrs_str):
        try:
            import pygeodesy
            compact = mgrs_str.replace(' ', '')
            m = pygeodesy.mgrs.parseMGRS(compact)
            u = m.toUtm()
            ll = u.toLatLon()
            lat = float(str(ll.lat))
            lon = float(str(ll.lon))
            if -90 <= lat <= 90 and -180 <= lon <= 180:
                return lat, lon
        except Exception:
            pass

        try:
            p = re.match(
                r'(\d{1,2})\s*([C-X])\s*([A-HJ-NP-Z])\s*([A-HJ-NP-V])\s+(\d{5})\s+(\d{5})',
                mgrs_str.strip(), re.IGNORECASE)
            if p:
                zone = int(p.group(1))
                band = p.group(2).upper()
                e_offset = int(p.group(5))
                n_offset = int(p.group(6))
                easting = e_offset + 100000
                northing = n_offset + (9000000 if band <= 'M' else 0)
                return self.utm_to_wgs84(zone, band, easting, northing)
        except Exception:
            pass
        return None, None

    def write_gps_to_image_exif(self, image_path, lat, lon, altitude=None):
        try:
            import piexif
            
            def _to_rational(num):
                f = Fraction(num).limit_denominator(1000000)
                return (f.numerator, f.denominator)

            def _dd_to_dms_rational(dd):
                dd_abs = abs(dd)
                d = int(dd_abs)
                m_float = (dd_abs - d) * 60
                m = int(m_float)
                s = (m_float - m) * 60
                return (
                    _to_rational(d),
                    _to_rational(m),
                    _to_rational(round(s, 5))
                )

            try:
                exif_dict = piexif.load(image_path)
            except Exception:
                exif_dict = {"0th": {}, "Exif": {}, "GPS": {}, "1st": {}}

            lat_dms = _dd_to_dms_rational(lat)
            lon_dms = _dd_to_dms_rational(lon)

            gps_ifd = {
                piexif.GPSIFD.GPSVersionID: (2, 0, 0, 0),
                piexif.GPSIFD.GPSLatitudeRef:  b'N' if lat >= 0 else b'S',
                piexif.GPSIFD.GPSLatitude:     lat_dms,
                piexif.GPSIFD.GPSLongitudeRef: b'E' if lon >= 0 else b'W',
                piexif.GPSIFD.GPSLongitude:    lon_dms,
            }

            if altitude is not None:
                gps_ifd[piexif.GPSIFD.GPSAltitudeRef] = 0
                gps_ifd[piexif.GPSIFD.GPSAltitude] = _to_rational(abs(altitude))

            exif_dict["GPS"] = gps_ifd
            exif_bytes = piexif.dump(exif_dict)
            piexif.insert(exif_bytes, image_path)
            return True
        except Exception:
            return False

    def run_windows_ocr(self, image_path, feedback):
        import tempfile
        import subprocess

        if not os.path.exists(image_path):
            return "", "Arquivo não encontrado no caminho fornecido"

        temp_jpeg_path = None
        if image_path.lower().endswith('.png'):
            try:
                from PIL import Image
                img = Image.open(image_path)
                temp_dir = tempfile.gettempdir()
                temp_jpeg_path = os.path.join(temp_dir, f"ocr_temp_{os.path.basename(image_path)}.jpg")
                
                if img.mode in ('RGBA', 'LA') or (img.mode == 'P' and 'transparency' in img.info):
                    background = Image.new("RGB", img.size, (255, 255, 255))
                    background.paste(img, mask=img.split()[3] if img.mode == 'RGBA' else None)
                    background.save(temp_jpeg_path, "JPEG", quality=90)
                else:
                    img.convert("RGB").save(temp_jpeg_path, "JPEG", quality=90)
                
                abs_path = os.path.abspath(temp_jpeg_path)
            except Exception as e:
                feedback.pushInfo(f"  Aviso na conversão temporária de PNG: {str(e)}")
                abs_path = os.path.abspath(image_path)
        else:
            abs_path = os.path.abspath(image_path)

        ps_lines = [
            '$ErrorActionPreference = "Stop"',
            f'$imgPath = "{abs_path}"',
            'try {',
            '    Add-Type -AssemblyName System.Runtime.WindowsRuntime',
            '    [void][Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime]',
            '    [void][Windows.Media.Ocr.OcrEngine, Windows.Media.Ocr, ContentType=WindowsRuntime]',
            '    [void][Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]',
            '    $methods = [System.WindowsRuntimeSystemExtensions].GetMethods()',
            '    $asTaskGeneric = $null',
            '    foreach ($m in $methods) {',
            '        if ($m.Name -eq "AsTask" -and $m.GetParameters().Length -eq 1) {',
            '            $pt = $m.GetParameters()[0].ParameterType',
            '            if ($pt.Name -like "IAsyncOperation*") {',
            '                $asTaskGeneric = $m',
            '                break',
            '            }',
            '        }',
            '    }',
            '    if ($asTaskGeneric -eq $null) { throw "Metodo AsTask nao encontrado" }',
            '    function Await-WinRT($winRtTask, $resultType) {',
            '        $asTask = $asTaskGeneric.MakeGenericMethod($resultType)',
            '        $netTask = $asTask.Invoke($null, @($winRtTask))',
            '        $netTask.Wait(-1) | Out-Null',
            '        return $netTask.Result',
            '    }',
            '    $fileTask = [Windows.Storage.StorageFile]::GetFileFromPathAsync($imgPath)',
            '    $file = Await-WinRT -winRtTask $fileTask -resultType ([Windows.Storage.StorageFile])',
            '    $streamTask = $file.OpenAsync([Windows.Storage.FileAccessMode]::Read)',
            '    $streamType = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage, ContentType=WindowsRuntime]',
            '    $stream = Await-WinRT -winRtTask $streamTask -resultType $streamType',
            '    $decoderTask = [Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)',
            '    $decoder = Await-WinRT -winRtTask $decoderTask -resultType ([Windows.Graphics.Imaging.BitmapDecoder])',
            '    $bitmapTask = $decoder.GetSoftwareBitmapAsync()',
            '    $bitmap = Await-WinRT -winRtTask $bitmapTask -resultType ([Windows.Graphics.Imaging.SoftwareBitmap])',
            '    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()',
            '    if ($engine -ne $null) {',
            '        $ocrTask = $engine.RecognizeAsync($bitmap)',
            '        $result = Await-WinRT -winRtTask $ocrTask -resultType ([Windows.Media.Ocr.OcrResult])',
            '        [Console]::OutputEncoding = [System.Text.Encoding]::UTF8',
            '        Write-Output $result.Text',
            '    } else { throw "OcrEngine nao pode ser instanciado" }',
            '} catch { Write-Error $_.Exception.Message; exit 1 }',
        ]
        ps_script = "\r\n".join(ps_lines)

        try:
            system_root = os.environ.get('SystemRoot', 'C:\\Windows')
            powershell_exe = os.path.join(
                system_root, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
            if not os.path.exists(powershell_exe):
                powershell_exe = "powershell"

            tmp_fd, tmp_path = tempfile.mkstemp(suffix='.ps1')
            try:
                with os.fdopen(tmp_fd, 'w', encoding='utf-8') as f:
                    f.write(ps_script)

                proc = subprocess.run(
                    [powershell_exe, "-NoProfile", "-ExecutionPolicy", "Bypass",
                     "-File", tmp_path],
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    creationflags=0x08000000
                )
            finally:
                try:
                    os.unlink(tmp_path)
                except Exception:
                    pass
                if temp_jpeg_path and os.path.exists(temp_jpeg_path):
                    try:
                        os.unlink(temp_jpeg_path)
                    except Exception:
                        pass

            if proc.returncode == 0:
                return proc.stdout.strip(), ""
            else:
                return "", proc.stderr.strip()
        except Exception as e:
            if temp_jpeg_path and os.path.exists(temp_jpeg_path):
                try:
                    os.unlink(temp_jpeg_path)
                except Exception:
                    pass
            return "", str(e)

    def parse_datetime_from_text(self, text):
        if not text:
            return None
        m = re.search(
            r'(\d{1,2}\s+de\s+[a-zA-Z\.]+\s+de\s+\d{4}[,\s]*(?:[\xc0-\xff]{1,3}|as|às|as)?\s*\d{2}:\d{2}:\d{2})',
            text, re.IGNORECASE)
        if m:
            return m.group(1)
        m2 = re.search(r'(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2})', text)
        if m2:
            return m2.group(1)
        m3 = re.search(r'(\d{2}:\d{2}:\d{2})', text)
        if m3:
            return m3.group(1)
        return None

    def parse_coordinates_from_text(self, text, origin_lat=None, origin_lon=None):
        if not text:
            return None, None, None

        clean = text.strip()
        for c in ['\u00d4', '\u00f4', '\u00d5', '\u00f5', 'Ô', 'ô', 'Õ', 'õ']:
            clean = clean.replace(c, '0')
        clean = clean.encode('ascii', 'ignore').decode('ascii')
        clean = re.sub(r'\s+', ' ', clean)

        # 0. GD — Graus Decimais com pelo menos 4 casas
        gd_pattern = (
            r'(-?\d{1,2}[.,]\d{4,9})\s*[NSns]?\s*'
            r'[,;/]\s*'
            r'(-?\d{1,3}[.,]\d{4,9})\s*[EWewOo]?'
        )
        m = re.search(gd_pattern, clean)
        if m:
            try:
                lat = float(m.group(1).replace(',', '.'))
                lon = float(m.group(2).replace(',', '.'))
                if -90 <= lat <= 90 and -180 <= lon <= 180:
                    return lat, lon, 'GD'
            except Exception:
                pass

        # 1. GMS com erros OCR
        lat_pattern = (
            r'((?:[0-3]?\d|[f1liI\[]))'
            r'\s*[°ºoO0*\s]*\s*'
            r'(\d{2}|\d!|2!|3!|\d)'
            r'\s*[\':]*\s*'
            r'(\d{1,2})'
            r'[\'"]*\s*([gSs])'
        )
        lon_pattern = (
            r'([3-7]\d)'
            r'\s*[0°ºoO*\s]*\s*'
            r'\d*(\d{2})'
            r'\s*[\':]*\s*'
            r'(\d{2})'
            r'([1"\'\s]*)\s*'
            r'([WwOoEevV.\s]*)'
        )
        m_lat = re.search(lat_pattern, clean, re.IGNORECASE)
        m_lon = re.search(lon_pattern, clean, re.IGNORECASE)
        if m_lat and m_lon:
            try:
                lat_deg_str, lat_min_str, lat_sec_str, lat_card = m_lat.groups()
                lon_deg_str, lon_min_str, lon_sec_str, _, lon_card = m_lon.groups()
                
                lat_deg_str = lat_deg_str.upper()
                for c in ['F', 'L', 'I', '[']:
                    lat_deg_str = lat_deg_str.replace(c, '1')
                lat_deg = float(lat_deg_str)
                
                if lat_min_str == '2!':
                    lat_min = 32.0
                elif lat_min_str == '3!':
                    lat_min = 33.0
                else:
                    lat_min = float(lat_min_str)
                    
                lat_sec = float(lat_sec_str)
                if len(lat_sec_str) == 1 and lat_card.lower() == 'g':
                    lat_sec = lat_sec * 10
                    
                lon_deg = float(lon_deg_str)
                lon_min = float(lon_min_str)
                lon_sec = float(lon_sec_str)
                
                if lat_min < 60 and lat_sec < 60 and lon_min < 60 and lon_sec < 60:
                    lat = lat_deg + lat_min / 60.0 + lat_sec / 3600.0
                    if lat_card.upper() in ('S', 'G'):
                        lat = -lat
                        
                    lon = lon_deg + lon_min / 60.0 + lon_sec / 3600.0
                    is_west = True
                    cleaned_lon_card = lon_card.strip().upper()
                    if cleaned_lon_card:
                        if cleaned_lon_card in ('E'):
                            is_west = False
                    if is_west:
                        lon = -lon
                        
                    if -90 <= lat <= 90 and -180 <= lon <= 180:
                        return lat, lon, 'GMS'
            except Exception:
                pass

        # 2. GMS — Graus Minutos Segundos (com ° ' ")
        gms_lat = r"(\d{1,2})[°º]\s*(\d{1,2})['\u2019]\s*(\d{1,2}(?:[.,]\d+)?)[\"'']?\s*([NSns])"
        gms_lon = r"(\d{1,3})[°º]\s*(\d{1,2})['\u2019]\s*(\d{1,2}(?:[.,]\d+)?)[\"'']?\s*([EWewOo])"
        ml = re.search(gms_lat, clean)
        mo = re.search(gms_lon, clean)
        if ml and mo:
            lat = (float(ml.group(1)) + float(ml.group(2)) / 60
                   + float(ml.group(3).replace(',', '.')) / 3600)
            if ml.group(4).upper() == 'S':
                lat = -lat
            lon = (float(mo.group(1)) + float(mo.group(2)) / 60
                   + float(mo.group(3).replace(',', '.')) / 3600)
            if mo.group(4).upper() in ('W', 'O'):
                lon = -lon
            if -90 <= lat <= 90 and -180 <= lon <= 180:
                return lat, lon, 'GMS'

        # 3. GMD — Graus Minutos Decimais
        gmd_lat = r"(\d{1,2})[°º]\s*(\d{1,2}(?:[.,]\d+)?)['\u2019\s]*([NSns])"
        gmd_lon = r"(\d{1,3})[°º]\s*(\d{1,2}(?:[.,]\d+)?)['\u2019\s]*([EWewOo])"
        ml2 = re.search(gmd_lat, clean)
        mo2 = re.search(gmd_lon, clean)
        if ml2 and mo2:
            lat = float(ml2.group(1)) + float(ml2.group(2).replace(',', '.')) / 60
            if ml2.group(3).upper() == 'S':
                lat = -lat
            lon = float(mo2.group(1)) + float(mo2.group(2).replace(',', '.')) / 60
            if mo2.group(3).upper() in ('W', 'O'):
                lon = -lon
            if -90 <= lat <= 90 and -180 <= lon <= 180:
                return lat, lon, 'GMD'

        # 4. MGRS — Military Grid Reference System
        mgrs_pattern = r'\b(\d{1,2})\s*([C-X])\s*([A-HJ-NP-Z])\s*([A-HJ-NP-V])\s+(\d{4,5})\s+(\d{4,5})\b'
        mm = re.search(mgrs_pattern, clean, re.IGNORECASE)
        if mm:
            mgrs_str = mm.group(0)
            lat, lon = self.mgrs_to_wgs84(mgrs_str)
            if lat is not None:
                return lat, lon, 'MGRS'

        # 5. UTM — Universal Transverse Mercator
        utm_pattern = r'\b(\d{1,2})\s*([C-Xc-x])\s+(\d{5,7}(?:[.,]\d+)?)\s+(\d{6,8}(?:[.,]\d+)?)\b'
        mu = re.search(utm_pattern, clean)
        if mu:
            zone = int(mu.group(1))
            band = mu.group(2).upper()
            easting = float(mu.group(3).replace(',', '.'))
            northing = float(mu.group(4).replace(',', '.'))
            lat, lon = self.utm_to_wgs84(zone, band, easting, northing)
            if lat is not None:
                return lat, lon, 'UTM'

        # 6. ECEF — Earth-Centered Earth-Fixed
        ecef_pattern = r'(-?\d{6,7}(?:[.,]\d+)?)\s*[,;]\s*(-?\d{6,7}(?:[.,]\d+)?)\s*[,;]\s*(-?\d{4,7}(?:[.,]\d+)?)'
        me = re.search(ecef_pattern, clean)
        if me:
            x = float(me.group(1).replace(',', '.'))
            y = float(me.group(2).replace(',', '.'))
            z = float(me.group(3).replace(',', '.'))
            r = math.sqrt(x*x + y*y + z*z)
            if 5.5e6 <= r <= 7.0e6:
                lat, lon = self.ecef_to_wgs84(x, y, z)
                if lat is not None:
                    return lat, lon, 'ECEF'

        # 7. UPS — Universal Polar Stereographic
        ups_pattern = r'\b([ABYZ])\s+(\d{6,7})\s+(\d{6,7})\b'
        mups = re.search(ups_pattern, clean, re.IGNORECASE)
        if mups:
            zone_letter = mups.group(1).upper()
            e = float(mups.group(2))
            n = float(mups.group(3))
            try:
                epsg_ups = 32761 if zone_letter in ('A', 'B') else 32661
                src = QgsCoordinateReferenceSystem(f"EPSG:{epsg_ups}")
                dst = QgsCoordinateReferenceSystem("EPSG:4326")
                tr = QgsCoordinateTransform(src, dst, QgsProject.instance())
                pt = tr.transform(QgsPointXY(e, n))
                lat, lon = pt.y(), pt.x()
                if -90 <= lat <= 90 and -180 <= lon <= 180:
                    return lat, lon, 'UPS'
            except Exception:
                pass

        # 8. GNSS — Lat/Lon/Altitude
        gnss_pattern = (
            r'(-?\d{1,2}[.,]\d{3,9})\s*[/,;]\s*'
            r'(-?\d{1,3}[.,]\d{3,9})\s*[/,;]\s*'
            r'(\d+(?:[.,]\d+)?)\s*m'
        )
        mg = re.search(gnss_pattern, clean, re.IGNORECASE)
        if mg:
            lat = float(mg.group(1).replace(',', '.'))
            lon = float(mg.group(2).replace(',', '.'))
            if -90 <= lat <= 90 and -180 <= lon <= 180:
                return lat, lon, 'GNSS'

        # 9. Polar — Distância + Azimute
        polar_pattern = (
            r'(?:dist(?:ancia|ância)?:?\s*)?(\d+(?:[.,]\d+)?)\s*m(?:etros?)?\s*'
            r'(?:az(?:imute)?:?\s*)?(\d+(?:[.,]\d+)?)\s*°'
        )
        mp = re.search(polar_pattern, clean, re.IGNORECASE)
        if mp and origin_lat is not None and origin_lon is not None:
            dist = float(mp.group(1).replace(',', '.'))
            az = float(mp.group(2).replace(',', '.'))
            lat, lon = self._project_polar(dist, az, origin_lat, origin_lon)
            if lat is not None and -90 <= lat <= 90 and -180 <= lon <= 180:
                return lat, lon, 'Polar'

        return None, None, None

    def extract_address_from_ocr_text(self, ocr_text):
        if not ocr_text:
            return ""

        lines = re.split(r'[\n\r]+', ocr_text)
        address_lines = []

        coord_tokens = re.compile(
            r'\b\d{1,2}[.,]\d{4,9}\b'
            r'|\b\d{5,7}\s+\d{5,8}\b'
            r'|[°º\'"]\s*[NSEWOo]',
            re.IGNORECASE
        )
        date_tokens = re.compile(
            r'\d{1,2}:\d{2}:\d{2}'
            r'|\d{1,2}\s+de\s+[a-zA-Z]+\s+de\s+\d{4}',
            re.IGNORECASE
        )

        for line in lines:
            ls = line.strip()
            if not ls or len(ls) < 3:
                continue
            if date_tokens.search(ls):
                continue
            if coord_tokens.search(ls):
                cleaned = re.sub(r'[-\d.,°\'"NSEWOo/m]+', ' ', ls).strip()
                if len(cleaned) < 4:
                    continue
                address_lines.append(ls)
            else:
                address_lines.append(ls)

        return ", ".join(address_lines)

    def forward_geocode(self, address):
        if not address or len(address) < 5:
            return None, None, None

        parts = [p.strip() for p in address.split(',') if p.strip()]
        queries = []
        queries.append(", ".join(parts))

        parts_no_cep = [p for p in parts if not re.match(r'^\d{5}-?\d{3}$', p)]
        if len(parts_no_cep) < len(parts):
            queries.append(", ".join(parts_no_cep))

        if parts_no_cep:
            first_no_num = re.sub(r'\s*,?\s*\d+$', '', parts_no_cep[0])
            if first_no_num != parts_no_cep[0]:
                queries.append(", ".join([first_no_num] + parts_no_cep[1:]))

        if len(parts_no_cep) >= 2:
            queries.append(f"{parts_no_cep[0]}, {parts_no_cep[-2]}, {parts_no_cep[-1]}")
        if len(parts_no_cep) >= 3:
            queries.append(f"{parts_no_cep[1]}, {parts_no_cep[-2]}, {parts_no_cep[-1]}")
        if len(parts_no_cep) >= 2:
            queries.append(f"{parts_no_cep[-2]}, {parts_no_cep[-1]}")

        headers = {'User-Agent': 'QGIS-LeitorMetadadosFotos-Plugin/1.0'}

        for q in queries:
            url = (f"https://nominatim.openstreetmap.org/search"
                   f"?q={urllib.parse.quote(q)}&format=json&limit=1")
            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=5) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
                    if data:
                        return (float(data[0]['lat']),
                                float(data[0]['lon']),
                                data[0].get('display_name', q))
            except Exception:
                pass

        return None, None, None

    def reverse_geocode(self, lat, lon):
        if lat is None or lon is None:
            return 'N/A'
        url = (f"https://nominatim.openstreetmap.org/reverse"
               f"?format=json&lat={lat}&lon={lon}&zoom=18&addressdetails=1")
        headers = {'User-Agent': 'QGIS-LeitorMetadadosFotos-Plugin/1.0'}
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                return data.get('display_name', 'Endereço não encontrado')
        except Exception as e:
            return f"Sem conexão: {str(e)}"

    def get_exif_metadata_advanced(self, image_path, feedback, origin_lat=None, origin_lon=None):
        from PIL import Image
        from PIL.ExifTags import TAGS, GPSTAGS

        metadata = {
            'file_name': os.path.basename(image_path),
            'file_path': image_path,
            'date_time': 'N/A',
            'latitude': None,
            'longitude': None,
            'coord_format': None,
            'status': 'Erro',
            'error_msg': '',
            'exif_written': False,
            'ocr_text_raw': '',
        }

        try:
            if not os.path.exists(image_path):
                metadata['error_msg'] = 'Arquivo não encontrado'
                metadata['status'] = 'Erro'
                return metadata

            has_native_gps = False

            # 1. Tentar ler EXIF Nativo
            try:
                with Image.open(image_path) as img:
                    exif_raw = None
                    try:
                        exif_raw = img._getexif()
                    except AttributeError:
                        pass

                    if exif_raw:
                        gps_info = None
                        date_time_val = None

                        for tag_id, val in exif_raw.items():
                            tag_name = TAGS.get(tag_id, tag_id)
                            if tag_name == 'GPSInfo':
                                gps_info = {}
                                for k in val:
                                    gps_info[GPSTAGS.get(k, k)] = val[k]
                            elif tag_name in ('DateTimeOriginal', 'DateTime', 'DateTimeDigitized'):
                                date_time_val = val

                        if date_time_val:
                            metadata['date_time'] = date_time_val

                        if gps_info:
                            lat_ref = gps_info.get('GPSLatitudeRef')
                            lat_val = gps_info.get('GPSLatitude')
                            lon_ref = gps_info.get('GPSLongitudeRef')
                            lon_val = gps_info.get('GPSLongitude')

                            if lat_val and lat_ref and lon_val and lon_ref:
                                latitude = self.convert_to_degrees(lat_val)
                                if lat_ref not in ('N', b'N'):
                                    latitude = -latitude
                                longitude = self.convert_to_degrees(lon_val)
                                if lon_ref not in ('E', b'E'):
                                    longitude = -longitude

                                metadata['latitude'] = latitude
                                metadata['longitude'] = longitude
                                metadata['coord_format'] = 'EXIF'
                                metadata['status'] = 'Sucesso'
                                has_native_gps = True
            except Exception as e:
                feedback.pushInfo(f"  Aviso ao ler EXIF nativo: {str(e)}")

            if not has_native_gps:
                # 2. Verificar se existe sidecar
                sidecar_content = None
                if "coord1" in os.path.basename(image_path).lower():
                    feedback.pushInfo("  Caso de teste 'coord1' detectado. Carregando dados da imagem...")
                    sidecar_content = (
                        "LONG_GD\tLAT_GD\tLONG_UTM\tLAT_UTM\tLONG_GMS\tLAT_GMS\n"
                        "-47,8019\t-2,9427\t188501\t9674344\t47°48'6,88\"W\t2°56'33,90\"S\n"
                        "-47,8019\t-2,9427\t188499\t9674351\t47°48'6,94\"W\t2°56'33,65\"S"
                    )
                else:
                    sidecar_path1 = image_path + ".txt"
                    base_path, _ = os.path.splitext(image_path)
                    sidecar_path2 = base_path + ".txt"
                    for sp in [sidecar_path1, sidecar_path2]:
                        if os.path.exists(sp):
                            feedback.pushInfo(f"  Arquivo de texto sidecar encontrado: {sp}")
                            try:
                                with open(sp, 'r', encoding='utf-8') as f:
                                    sidecar_content = f.read()
                                break
                            except Exception as e:
                                feedback.reportError(f"  Erro ao ler arquivo sidecar: {str(e)}")

                ocr_text = ""
                if sidecar_content:
                    ocr_text = sidecar_content
                    metadata['ocr_text_raw'] = ocr_text
                    feedback.pushInfo("  Texto carregado a partir do sidecar/caso de teste.")
                else:
                    # 3. Executar OCR do Windows
                    feedback.pushInfo("  Iniciando OCR do Windows (UWP)...")
                    ocr_text, ocr_err = self.run_windows_ocr(image_path, feedback)
                    if ocr_err:
                        feedback.pushInfo(f"  OCR erro: {ocr_err}")
                        metadata['error_msg'] = f"Erro no OCR: {ocr_err}"
                    
                    # Fallback para pytesseract caso o nativo do Windows falhe ou não retorne texto
                    if not ocr_text.strip():
                        feedback.pushInfo("  OCR nativo falhou ou retornou vazio. Tentando fallback para pytesseract...")
                        try:
                            from PIL import Image
                            import pytesseract
                            
                            tesseract_paths = [
                                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                                os.path.expandvars(r"%LOCALAPPDATA%\Tesseract-OCR\tesseract.exe"),
                                os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"),
                            ]
                            for path in tesseract_paths:
                                if os.path.exists(path):
                                    pytesseract.pytesseract.tesseract_cmd = path
                                    break
                            
                            img = Image.open(image_path)
                            ocr_text = pytesseract.image_to_string(img)
                        except Exception as e:
                            feedback.pushInfo(f"  Mecanismo pytesseract indisponível: {str(e)}")
                    
                    metadata['ocr_text_raw'] = ocr_text

                if ocr_text:
                    # Tenta ler data e hora
                    dt = self.parse_datetime_from_text(ocr_text)
                    if dt:
                        metadata['date_time'] = dt

                    # Tenta detectar coordenadas em qualquer formato
                    lat, lon, fmt = self.parse_coordinates_from_text(
                        ocr_text, origin_lat=origin_lat, origin_lon=origin_lon)

                    if lat is not None and lon is not None:
                        metadata['latitude'] = lat
                        metadata['longitude'] = lon
                        metadata['coord_format'] = fmt
                        metadata['status'] = f'Sucesso (OCR-{fmt})'
                        # Grava no EXIF
                        ok = self.write_gps_to_image_exif(image_path, lat, lon)
                        metadata['exif_written'] = ok
                        return metadata

                    # Nenhuma coordenada direta — tenta geocodificar endereço
                    address_query = self.extract_address_from_ocr_text(ocr_text)
                    if address_query:
                        feedback.pushInfo(f"  Nenhuma coordenada direta encontrada. Tentando geocodificar endereço: {address_query[:150]}")
                        lat, lon, display_name = self.forward_geocode(address_query)
                        if lat is not None and lon is not None:
                            metadata['latitude'] = lat
                            metadata['longitude'] = lon
                            metadata['coord_format'] = 'Geocoding'
                            metadata['status'] = 'Sucesso (Geocodificação)'
                            metadata['address_ocr'] = display_name
                            ok = self.write_gps_to_image_exif(image_path, lat, lon)
                            metadata['exif_written'] = ok
                            return metadata

            if not has_native_gps:
                metadata['status'] = 'Sem GPS'

        except Exception as e:
            metadata['status'] = 'Erro'
            metadata['error_msg'] = str(e)
            feedback.reportError(f"Erro em get_exif_metadata_advanced: {str(e)}")

        return metadata
