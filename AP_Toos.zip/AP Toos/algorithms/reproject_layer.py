# -*- coding: utf-8 -*-
"""
AP Toos - Reprojetar Camada Vetorial
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

import processing
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterCrs,
    QgsProcessingParameterFeatureSink,
    QgsProcessingException
)
from qgis.PyQt.QtCore import QCoreApplication


class ReprojectLayer(QgsProcessingAlgorithm):
    """Reprojetar Camada Vetorial - Reprojeta uma camada para um novo SRC."""

    INPUT = 'INPUT'
    TARGET_CRS = 'TARGET_CRS'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                QCoreApplication.translate('ReprojectLayer', 'Camada Vetorial de Entrada'),
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )
        self.addParameter(
            QgsProcessingParameterCrs(
                self.TARGET_CRS,
                QCoreApplication.translate('ReprojectLayer', 'Sistema de Referência de Coordenadas de Destino (CRS)')
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                QCoreApplication.translate('ReprojectLayer', 'Camada Reprojetada')
            )
        )

    def name(self):
        return 'reproject_layer'

    def displayName(self):
        return QCoreApplication.translate('ReprojectLayer', 'Reprojetar Camada Vetorial')

    def group(self):
        return QCoreApplication.translate('ReprojectLayer', 'Vetores')

    def groupId(self):
        return 'vetores'

    def shortHelpString(self):
        return QCoreApplication.translate(
            'ReprojectLayer',
            "Reprojeta uma camada vetorial para um novo Sistema de Referência de Coordenadas (CRS) especificado pelo usuário.\n\n"
            "Esta ferramenta realiza o alinhamento das geometrias no novo sistema, "
            "preservando integralmente a tabela de atributos original.\n\n"
            "Copyright: © Alessandro Pimentel 2026, Especialista em Geoprocessamento"
        )

    def createInstance(self):
        return ReprojectLayer()

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.tr("Não foi possível carregar a camada de entrada."))

        target_crs = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        feedback.pushInfo(f"Reprojetando camada para {target_crs.authid()}...")

        # Parâmetros para o algoritmo nativo de reprojeção
        reproject_params = {
            'INPUT': parameters[self.INPUT],
            'TARGET_CRS': parameters[self.TARGET_CRS],
            'OUTPUT': parameters[self.OUTPUT]
        }

        # Rodar o algoritmo
        results = processing.run(
            "native:reprojectlayer",
            reproject_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        dest_id = results.get('OUTPUT')
        if dest_id is None:
            raise QgsProcessingException(self.tr("Erro ao executar a reprojeção da camada."))

        feedback.pushInfo("© Alessandro Pimentel 2026, Especialista em Geoprocessamento - Camada Reprojetada!")
        return {self.OUTPUT: dest_id}
