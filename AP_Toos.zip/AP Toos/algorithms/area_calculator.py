# -*- coding: utf-8 -*-
"""
AP Toos - Calculadora de Área
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterEnum,
    QgsProcessingParameterString,
    QgsProcessingParameterFeatureSink,
    QgsProcessingException,
    QgsField,
    QgsFeature,
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextScope,
    QgsExpressionContextUtils,
    QgsFeatureSink
)
from qgis.PyQt.QtCore import QVariant, QCoreApplication


class AreaCalculator(QgsProcessingAlgorithm):
    """Calculadora de Área - Calcula a área de polígonos em m², ha ou km² usando expressões QGIS."""

    INPUT = 'INPUT'
    UNIT = 'UNIT'
    FIELD_NAME = 'FIELD_NAME'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                QCoreApplication.translate('AreaCalculator', 'Camada de Polígono de Entrada'),
                [QgsProcessing.TypeVectorPolygon]
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.UNIT,
                QCoreApplication.translate('AreaCalculator', 'Unidade de Área'),
                options=[
                    QCoreApplication.translate('AreaCalculator', 'm² (Metro quadrado)'),
                    QCoreApplication.translate('AreaCalculator', 'ha (Hectare)'),
                    QCoreApplication.translate('AreaCalculator', 'km² (Quilômetro quadrado)')
                ],
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.FIELD_NAME,
                QCoreApplication.translate('AreaCalculator', 'Nome do Novo Campo'),
                defaultValue='area_calc'
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                QCoreApplication.translate('AreaCalculator', 'Camada com Área Calculada')
            )
        )

    def name(self):
        return 'area_calculator'

    def displayName(self):
        return QCoreApplication.translate('AreaCalculator', 'Calculadora de Área')

    def group(self):
        return QCoreApplication.translate('AreaCalculator', 'Vetores')

    def groupId(self):
        return 'vetores'

    def shortHelpString(self):
        return QCoreApplication.translate(
            'AreaCalculator',
            "Calcula a área de polígonos utilizando as expressões regulamentares do QGIS:\n\n"
            "- m²: area(@geometry)\n"
            "- ha: area(@geometry) / 10000\n"
            "- km²: area(@geometry) / 1000000\n\n"
            "O usuário pode escolher a unidade desejada e o nome do campo a ser criado na tabela de atributos.\n\n"
            "Copyright: © Alessandro Pimentel 2026, Especialista em Geoprocessamento"
        )

    def createInstance(self):
        return AreaCalculator()

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.tr("Não foi possível carregar a camada de entrada."))

        unit_idx = self.parameterAsEnum(parameters, self.UNIT, context)
        field_name = self.parameterAsString(parameters, self.FIELD_NAME, context)

        if not field_name:
            field_name = 'area_calc'

        # Expressões obrigatórias solicitadas pelo usuário
        expressions_map = {
            0: "area(@geometry)",
            1: "area(@geometry) / 10000",
            2: "area(@geometry) / 1000000"
        }

        expr_str = expressions_map.get(unit_idx, "area(@geometry)")
        feedback.pushInfo(f"Utilizando expressão: {expr_str}")

        expr = QgsExpression(expr_str)
        if expr.hasParserError():
            raise QgsProcessingException(
                self.tr(f"Erro ao compilar expressão de área '{expr_str}': {expr.parserErrorString()}")
            )

        # Preparar campos da camada de saída
        fields = source.fields()
        
        # Adicionar novo campo para área (tipo Real/Double)
        # Se o campo já existir, adicionamos um sufixo para evitar conflitos
        final_field_name = field_name
        suffix = 1
        while fields.indexOf(final_field_name) != -1:
            final_field_name = f"{field_name}_{suffix}"
            suffix += 1

        fields.append(QgsField(final_field_name, QVariant.Double, 'Double', 20, 2))

        # Configurar pia de saída (sink)
        (sink, dest_id) = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            fields,
            source.wkbType(),
            source.sourceCrs()
        )

        if sink is None:
            raise QgsProcessingException(self.tr("Não foi possível criar o arquivo de saída."))

        # Configurar contexto de expressão QGIS
        expr_context = QgsExpressionContext()
        expr_context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(None))
        
        # Escopo do recurso para ser atualizado dinamicamente por feição
        feature_scope = QgsExpressionContextScope()
        expr_context.appendScope(feature_scope)

        # Processar feições
        features = source.getFeatures()
        total = 100.0 / source.featureCount() if source.featureCount() > 0 else 0

        for current, feature in enumerate(features):
            if feedback.isCanceled():
                break

            new_feature = QgsFeature(feature)
            geom = feature.geometry()

            area_val = QVariant(QVariant.Double)

            if geom is not None and not geom.isEmpty():
                # Atualizar variáveis de escopo
                feature_scope.setFeature(feature)
                feature_scope.setVariable("geometry", geom)

                # Calcular área
                val = expr.evaluate(expr_context)
                if val is not None and val != QVariant():
                    area_val = round(float(val), 2)

            # Gravar novo atributo
            new_attrs = feature.attributes() + [area_val]
            new_feature.setAttributes(new_attrs)
            sink.addFeature(new_feature, QgsFeatureSink.FastInsert)

            feedback.setProgress(int(current * total))

        feedback.pushInfo(f"Cálculos de área concluídos. Campo criado: '{final_field_name}'")
        feedback.pushInfo("© Alessandro Pimentel 2026, Especialista em Geoprocessamento - Área Calculada!")

        return {self.OUTPUT: dest_id}
