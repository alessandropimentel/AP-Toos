# -*- coding: utf-8 -*-
"""
AP Toos - Criar Ponto (x,y)
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

import re
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterEnum,
    QgsProcessingParameterString,
    QgsProcessingParameterCrs,
    QgsProcessingParameterFeatureSink,
    QgsProcessingException,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsWkbTypes,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject
)
from qgis.PyQt.QtCore import QVariant, QCoreApplication


def parse_dms(dms_str):
    """Converte uma string GMS (ex: 47°48'6,88\"W ou -47 48 6.88) para float decimal."""
    dms_str = dms_str.strip()
    if not dms_str:
        return 0.0

    # Padrão Regex para capturar Graus, Minutos, Segundos e a Cardinalidade (opcional)
    dms_pattern = r'(\d+)\s*[°º\s]\s*(\d+)\s*[\'´\s]\s*(\d+(?:[.,]\d+)?)\s*["”]?\s*([NSEWO]?)'
    match = re.search(dms_pattern, dms_str, re.IGNORECASE)
    
    if match:
        d, m, s, card = match.groups()
        val = int(d) + int(m) / 60.0 + float(s.replace(',', '.')) / 3600.0
        
        card = card.upper()
        # Se for Sul (S), Oeste (W ou O)
        if card in ['S', 'W', 'O']:
            val = -val
        elif not card:
            # Caso não tenha cardinalidade textual, verifica se a string original começa com sinal de menos
            if dms_str.startswith('-'):
                val = -val
        return val
    else:
        # Se não casar no padrão DMS, tenta converter diretamente para decimal (caso de o usuário digitar Grau Decimal por engano)
        try:
            return float(dms_str.replace(',', '.'))
        except ValueError:
            raise QgsProcessingException(
                f"Formato GMS inválido para a coordenada: '{dms_str}'. Exemplo de formato válido: 47°48'6,88\"W"
            )


class CreatePoint(QgsProcessingAlgorithm):
    """Criar Ponto (x,y) - Plota um ponto a partir de coordenadas em múltiplos formatos (GD, GMS, UTM)."""

    INPUT_FORMAT = 'INPUT_FORMAT'
    X = 'X'
    Y = 'Y'
    CRS = 'CRS'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterEnum(
                self.INPUT_FORMAT,
                QCoreApplication.translate('CreatePoint', 'Formato das Coordenadas de Entrada'),
                options=[
                    QCoreApplication.translate('CreatePoint', 'Grau Decimal (ex: X: -47.8019, Y: -2.9427)'),
                    QCoreApplication.translate('CreatePoint', 'Grau, Minuto e Segundo - GMS (ex: X: 47°48\'6,88\"W, Y: 2°56\'33,90\"S)'),
                    QCoreApplication.translate('CreatePoint', 'UTM (ex: X: 188501, Y: 9674344)')
                ],
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.X,
                QCoreApplication.translate('CreatePoint', 'Coordenada X (Longitude / Leste / DMS Longitude)'),
                defaultValue='0.0'
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.Y,
                QCoreApplication.translate('CreatePoint', 'Coordenada Y (Latitude / Norte / DMS Latitude)'),
                defaultValue='0.0'
            )
        )
        self.addParameter(
            QgsProcessingParameterCrs(
                self.CRS,
                QCoreApplication.translate('CreatePoint', 'Sistema de Referência de Coordenadas (CRS)'),
                defaultValue='EPSG:4674'
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                QCoreApplication.translate('CreatePoint', 'Ponto Criado')
            )
        )

    def name(self):
        return 'create_point'

    def displayName(self):
        return QCoreApplication.translate('CreatePoint', 'Criar Ponto (x,y)')

    def group(self):
        return QCoreApplication.translate('CreatePoint', 'Vetores')

    def groupId(self):
        return 'vetores'

    def shortHelpString(self):
        return QCoreApplication.translate(
            'CreatePoint',
            "Gera uma camada contendo um ponto com base nas coordenadas X e Y informadas, "
            "suportando múltiplos formatos de entrada:\n\n"
            "- Grau Decimal: valores numéricos decimais normais.\n"
            "- Grau, Minuto e Segundo (GMS): valores textuais contendo símbolos (ex: 47°48'6,88\"W).\n"
            "- UTM: coordenadas projetadas planas.\n\n"
            "O ponto gerado será corretamente projetado para o CRS selecionado pelo usuário.\n\n"
            "Copyright: © Alessandro Pimentel 2026, Especialista em Geoprocessamento"
        )

    def createInstance(self):
        return CreatePoint()

    def processAlgorithm(self, parameters, context, feedback):
        format_idx = self.parameterAsEnum(parameters, self.INPUT_FORMAT, context)
        x_str = self.parameterAsString(parameters, self.X, context).strip()
        y_str = self.parameterAsString(parameters, self.Y, context).strip()
        crs = self.parameterAsCrs(parameters, self.CRS, context)

        # 1. Determinar coordenadas em float baseando-se no formato selecionado
        if format_idx == 0:  # Grau Decimal
            try:
                x_val = float(x_str.replace(',', '.'))
                y_val = float(y_str.replace(',', '.'))
            except ValueError:
                raise QgsProcessingException(
                    self.tr("Coordenadas inválidas para Grau Decimal. Digite números decimais (ex: X: -47.8019, Y: -2.9427).")
                )
            pt = QgsPointXY(x_val, y_val)
            
        elif format_idx == 1:  # Grau, Minuto e Segundo (GMS)
            x_val = parse_dms(x_str)
            y_val = parse_dms(y_str)
            
            # GMS é inerentemente geográfico (referenciado em WGS 84 / EPSG:4326)
            src_crs = QgsCoordinateReferenceSystem("EPSG:4326")
            pt_geo = QgsPointXY(x_val, y_val)
            
            # Se o CRS final do usuário for diferente de WGS 84, faz a reprojeção
            if crs.authid() != src_crs.authid():
                transform = QgsCoordinateTransform(
                    src_crs, 
                    crs, 
                    context.transformContext() if hasattr(context, 'transformContext') else QgsProject.instance()
                )
                try:
                    pt = transform.transform(pt_geo)
                except Exception as e:
                    raise QgsProcessingException(
                        self.tr(f"Erro ao reprojetar coordenadas GMS para o CRS de destino: {str(e)}")
                    )
            else:
                pt = pt_geo
                
        else:  # UTM
            try:
                x_val = float(x_str.replace(',', '.'))
                y_val = float(y_str.replace(',', '.'))
            except ValueError:
                raise QgsProcessingException(
                    self.tr("Coordenadas inválidas para UTM. Digite valores numéricos inteiros ou decimais (ex: X: 188501, Y: 9674344).")
                )
            # UTM plota diretamente no CRS selecionado (que deve ser um CRS projetado)
            pt = QgsPointXY(x_val, y_val)

        # Configurar estrutura de campos
        fields = QgsFields()
        fields.append(QgsField('id', QVariant.Int, 'Integer'))
        fields.append(QgsField('x', QVariant.Double, 'Double', 20, 8))
        fields.append(QgsField('y', QVariant.Double, 'Double', 20, 8))
        fields.append(QgsField('tipo_input', QVariant.String, 'String', 50))

        # Configurar pia de saída (sink)
        (sink, dest_id) = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            fields,
            QgsWkbTypes.Point,
            crs
        )

        if sink is None:
            raise QgsProcessingException(self.tr("Não foi possível criar o arquivo de saída."))

        # Nomes de formato para a tabela de atributos
        format_names = {0: "Grau Decimal", 1: "GMS", 2: "UTM"}
        tipo_str = format_names.get(format_idx, "Desconhecido")

        # Criar e salvar feição
        feature = QgsFeature()
        feature.setGeometry(QgsGeometry.fromPointXY(pt))
        feature.setAttributes([1, pt.x(), pt.y(), tipo_str])
        
        sink.addFeature(feature)

        feedback.pushInfo(f"Ponto plotado com sucesso no formato '{tipo_str}' no CRS {crs.authid()}")
        feedback.pushInfo("© Alessandro Pimentel 2026, Especialista em Geoprocessamento - Ponto Plotado!")

        return {self.OUTPUT: dest_id}
