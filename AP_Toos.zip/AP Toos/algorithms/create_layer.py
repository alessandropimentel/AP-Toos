# -*- coding: utf-8 -*-
"""
AP Toos - Criar Camada
© Alessandro Pimentel 2026, Especialista em Geoprocessamento
"""

import os
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterCrs,
    QgsProcessingOutputVectorLayer,
    QgsProcessingException,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsWkbTypes,
    QgsVectorLayer,
    QgsVectorFileWriter,
    QgsProject,
    QgsProcessingContext,
    QgsDefaultValue
)
from qgis.PyQt.QtCore import QVariant, QCoreApplication


class CreateLayer(QgsProcessingAlgorithm):
    """Criar Camada - Cria uma nova camada (Ponto, Linha ou Polígono) temporária ou Shapefile,
    configurando expressões de valor padrão que calculam atributos automaticamente na edição geométrica.
    """

    NOMECAMADA = 'NOMECAMADA'
    TIPO_GEOMETRIA = 'TIPO_GEOMETRIA'
    TIPO_ARMAZENAMENTO = 'TIPO_ARMAZENAMENTO'
    CAMINHO_SHAPEFILE = 'CAMINHO_SHAPEFILE'
    CRS = 'CRS'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterString(
                self.NOMECAMADA,
                QCoreApplication.translate('CreateLayer', 'Nome da Camada'),
                defaultValue='Nova Camada'
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.TIPO_GEOMETRIA,
                QCoreApplication.translate('CreateLayer', 'Tipo de Geometria'),
                options=[
                    QCoreApplication.translate('CreateLayer', 'Ponto'),
                    QCoreApplication.translate('CreateLayer', 'Linha (Caminho)'),
                    QCoreApplication.translate('CreateLayer', 'Polígono (Área)')
                ],
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.TIPO_ARMAZENAMENTO,
                QCoreApplication.translate('CreateLayer', 'Tipo de Armazenamento'),
                options=[
                    QCoreApplication.translate('CreateLayer', 'Camada Temporária (Memória)'),
                    QCoreApplication.translate('CreateLayer', 'Arquivo Shapefile')
                ],
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.CAMINHO_SHAPEFILE,
                QCoreApplication.translate('CreateLayer', 'Caminho do Shapefile (Opcional se Temporária)'),
                fileFilter='Shapefiles (*.shp)',
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterCrs(
                self.CRS,
                QCoreApplication.translate('CreateLayer', 'Sistema de Referência de Coordenadas (CRS)'),
                defaultValue='EPSG:4674'
            )
        )
        self.addOutput(
            QgsProcessingOutputVectorLayer(
                self.OUTPUT,
                QCoreApplication.translate('CreateLayer', 'Camada Criada')
            )
        )

    def name(self):
        return 'create_layer'

    def displayName(self):
        return QCoreApplication.translate('CreateLayer', 'Criar Camada')

    def group(self):
        return QCoreApplication.translate('CreateLayer', 'Vetores')

    def groupId(self):
        return 'vetores'

    def shortHelpString(self):
        return QCoreApplication.translate(
            'CreateLayer',
            "Cria uma nova camada vetorial vazia contendo campos estruturados e autocalculados:\n\n"
            "- Polígono: calcula a área em hectares (AREA_HA) automaticamente na criação ou alteração da geometria.\n"
            "- Ponto: calcula as coordenadas geográficas (Graus Decimais e GMS em SIRGAS 2000) e UTM planas (arredondadas para 2 casas) dinamicamente na inserção/edição do ponto.\n"
            "- Linha: calcula o comprimento em metros (PERIM_M) arredondado para 2 casas decimais.\n\n"
            "Copyright: © Alessandro Pimentel 2026, Especialista em Geoprocessamento"
        )

    def createInstance(self):
        return CreateLayer()

    def processAlgorithm(self, parameters, context, feedback):
        layer_name = self.parameterAsString(parameters, self.NOMECAMADA, context).strip()
        geom_idx = self.parameterAsEnum(parameters, self.TIPO_GEOMETRIA, context)
        storage_idx = self.parameterAsEnum(parameters, self.TIPO_ARMAZENAMENTO, context)
        shp_path = self.parameterAsFileOutput(parameters, self.CAMINHO_SHAPEFILE, context)
        crs = self.parameterAsCrs(parameters, self.CRS, context)

        if not layer_name:
            layer_name = 'Nova Camada'

        # Validação do caminho do Shapefile caso o armazenamento seja físico
        if storage_idx == 1:
            if not shp_path:
                raise QgsProcessingException(
                    self.tr("Você selecionou o armazenamento 'Shapefile', portanto precisa especificar um caminho de saída válido.")
                )
            if not shp_path.lower().endswith('.shp'):
                shp_path += '.shp'

        # Mapeamento do tipo de geometria para string URI do provedor de memória
        geom_types_map = {
            0: ('Point', 'Ponto'),
            1: ('LineString', 'Linha'),
            2: ('Polygon', 'Polígono')
        }
        geom_uri_part, geom_label = geom_types_map.get(geom_idx, ('Point', 'Ponto'))

        feedback.pushInfo(f"Estruturando camada de {geom_label} no CRS {crs.authid()}...")

        # 1. Definir os campos e expressões de valor padrão por geometria
        fields = QgsFields()
        defaults = []

        if geom_idx == 2:  # Polígono
            fields.append(QgsField("ID", QVariant.Int, "Integer"))
            fields.append(QgsField("NOME", QVariant.String, "String", 100))
            fields.append(QgsField("DESCRICAO", QVariant.String, "String", 255))
            fields.append(QgsField("DT_CRIACAO", QVariant.String, "String", 50))
            fields.append(QgsField("AREA_HA", QVariant.Double, "Double", 20, 2))
            
            defaults = [
                ("ID", "coalesce(maximum(\"ID\"), 0) + 1", False),
                ("DT_CRIACAO", "format_date(now(), 'yyyy-MM-dd HH:mm:ss')", False),
                ("AREA_HA", "round(area($geometry) / 10000, 2)", True)
            ]
        elif geom_idx == 0:  # Ponto
            fields.append(QgsField("ID", QVariant.Int, "Integer"))
            fields.append(QgsField("NOME", QVariant.String, "String", 100))
            fields.append(QgsField("DESCRICAO", QVariant.String, "String", 255))
            fields.append(QgsField("LONG_GD", QVariant.Double, "Double", 20, 8))
            fields.append(QgsField("LAT_GD", QVariant.Double, "Double", 20, 8))
            fields.append(QgsField("LONG_GMS", QVariant.String, "String", 50))
            fields.append(QgsField("LAT_GMS", QVariant.String, "String", 50))
            fields.append(QgsField("LONG_UTM", QVariant.Double, "Double", 20, 2))
            fields.append(QgsField("LAT_UTM", QVariant.Double, "Double", 20, 2))
            fields.append(QgsField("DT_CRIACAO", QVariant.String, "String", 50))
            
            # Expressões inteligentes utilizando transform() para referenciar sempre SIRGAS 2000 (EPSG:4674)
            defaults = [
                ("ID", "coalesce(maximum(\"ID\"), 0) + 1", False),
                ("LONG_GD", "x(transform($geometry, @layer_crs, 'EPSG:4674'))", True),
                ("LAT_GD", "y(transform($geometry, @layer_crs, 'EPSG:4674'))", True),
                ("LONG_GMS", "replace(to_dms(x(transform($geometry, @layer_crs, 'EPSG:4674')), 'x', 2, 'suffix'), '.', ',')", True),
                ("LAT_GMS", "replace(to_dms(y(transform($geometry, @layer_crs, 'EPSG:4674')), 'y', 2, 'suffix'), '.', ',')", True),
                # UTM Dinâmico baseado no fuso e hemisfério calculados em tempo de execução
                ("LONG_UTM", "round(x(transform($geometry, @layer_crs, 'EPSG:' || to_string(if(y(transform($geometry, @layer_crs, 'EPSG:4674')) < 0, 31960 + floor((x(transform($geometry, @layer_crs, 'EPSG:4674')) + 180) / 6) + 1, 31954 + floor((x(transform($geometry, @layer_crs, 'EPSG:4674')) + 180) / 6) + 1)))), 2)", True),
                ("LAT_UTM", "round(y(transform($geometry, @layer_crs, 'EPSG:' || to_string(if(y(transform($geometry, @layer_crs, 'EPSG:4674')) < 0, 31960 + floor((x(transform($geometry, @layer_crs, 'EPSG:4674')) + 180) / 6) + 1, 31954 + floor((x(transform($geometry, @layer_crs, 'EPSG:4674')) + 180) / 6) + 1)))), 2)", True),
                ("DT_CRIACAO", "format_date(now(), 'yyyy-MM-dd HH:mm:ss')", False)
            ]
        else:  # Linha
            fields.append(QgsField("ID", QVariant.Int, "Integer"))
            fields.append(QgsField("NOME", QVariant.String, "String", 100))
            fields.append(QgsField("DESCRICAO", QVariant.String, "String", 255))
            fields.append(QgsField("PERIM_M", QVariant.Double, "Double", 20, 2))
            fields.append(QgsField("DT_CRIACAO", QVariant.String, "String", 50))
            
            defaults = [
                ("ID", "coalesce(maximum(\"ID\"), 0) + 1", False),
                ("PERIM_M", "round(length($geometry), 2)", True),
                ("DT_CRIACAO", "format_date(now(), 'yyyy-MM-dd HH:mm:ss')", False)
            ]

        # 2. Criar a camada temporária base na memória para receber a tabela de atributos
        uri = f"{geom_uri_part}?crs={crs.authid()}"
        mem_layer = QgsVectorLayer(uri, layer_name, "memory")
        pr = mem_layer.dataProvider()
        pr.addAttributes(fields)
        mem_layer.updateFields()

        # 3. Persistir em Shapefile se essa foi a opção de armazenamento
        if storage_idx == 1:
            feedback.pushInfo(f"Persistindo a camada fisicamente como Shapefile em: {shp_path}")
            
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "ESRI Shapefile"
            options.fileEncoding = "UTF-8"
            
            transform_context = context.transformContext() if hasattr(context, 'transformContext') else QgsProject.instance().transformContext()
            
            err, err_msg = QgsVectorFileWriter.writeAsVectorFormatV3(
                mem_layer,
                shp_path,
                transform_context,
                options
            )
            
            if err != QgsVectorFileWriter.NoError:
                raise QgsProcessingException(self.tr(f"Erro ao criar arquivo Shapefile: {err_msg}"))
            
            # Carregar o Shapefile criado como a camada alvo de trabalho
            layer = QgsVectorLayer(shp_path, layer_name, "ogr")
            if not layer.isValid():
                raise QgsProcessingException(self.tr("Não foi possível carregar a camada Shapefile após sua criação."))
        else:
            feedback.pushInfo("Criando a camada de forma temporária em memória...")
            layer = mem_layer

        # 4. Configurar as expressões de valor padrão na camada alvo
        for field_name, expr_str, eval_on_update in defaults:
            idx = layer.fields().indexFromName(field_name)
            if idx != -1:
                val_def = QgsDefaultValue()
                val_def.setExpression(expr_str)
                val_def.setApplyOnUpdate(eval_on_update)
                layer.setDefaultValueDefinition(idx, val_def)
                feedback.pushInfo(f"Gatilho ativado para o campo: '{field_name}' -> Expressão: {expr_str}")

        # 5. Adicionar a camada ao store temporário para evitar que saia de escopo na thread
        context.temporaryLayerStore().addMapLayer(layer)
        
        # Enfileira o carregamento na legenda ao finalizar o processamento
        context.addLayerToLoadOnCompletion(
            layer.id(),
            QgsProcessingContext.LayerDetails(layer_name, context.project(), self.OUTPUT)
        )

        feedback.pushInfo("© Alessandro Pimentel 2026, Especialista em Geoprocessamento - Camada Criada e Configurada!")
        return {self.OUTPUT: layer.id()}
